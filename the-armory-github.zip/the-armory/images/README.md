# Helmet photos

Put one photo per helmet in this folder, using these exact file names. A helmet with no photo shows as a text card.

| Helmet | File name |
| --- | --- |
| Mark 39 helmet | `mark39.jpg` |
| Symbiote Spiderman helmet | `symbiote.jpg` |
| Wearable decorated Mandalorian helmet | `mando-deco.jpg` |
| Mandalorian helmet, unfinished | `mando-raw.jpg` |
| Mandalorian helmet, finished | `mando-fin.jpg` |

Landscape photos around 1200 x 900 pixels work best.
